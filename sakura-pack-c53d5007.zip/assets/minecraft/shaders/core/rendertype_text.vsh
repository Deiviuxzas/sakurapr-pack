#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out float sakuraBadge;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    // SakuraPR banners: text coloured exactly #FBFFFB and its shadow (62,63,62) bob and pulse;
    // only the marker is recoloured to white, the shadow keeps its dark colour (others untouched)
    bool sakuraMark = all(lessThan(abs(Color.rgb - vec3(251.0, 255.0, 251.0) / 255.0), vec3(0.001)));
    bool sakuraFx = sakuraMark || all(lessThan(abs(Color.rgb - vec3(62.0, 63.0, 62.0) / 255.0), vec3(0.001)));
    if (sakuraFx) gl_Position.y += ProjMat[1][1] * sin(GameTime * 4000.0) * 1.5 * gl_Position.w;
    // Rank badges (badges.py): coloured exactly #FBFFFC, drawn white; the fragment shader adds a sheen
    sakuraBadge = all(lessThan(abs(Color.rgb - vec3(251.0, 255.0, 252.0) / 255.0), vec3(0.001))) ? 1.0 : 0.0;

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    if (sakuraBadge > 0.5) vertexColor = vec4(texelFetch(Sampler2, UV2 / 16, 0).rgb, vertexColor.a);
    if (sakuraFx) vertexColor = vec4(sakuraMark ? vec3(1.0) : vertexColor.rgb, (0.925 + 0.075 * sin(GameTime * 8000.0)) * vertexColor.a);
    texCoord0 = UV0;
}
