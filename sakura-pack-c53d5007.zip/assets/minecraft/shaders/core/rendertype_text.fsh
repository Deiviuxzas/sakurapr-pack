#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in float sakuraBadge;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    if (sakuraBadge > 0.5) {
        float b = fract((gl_FragCoord.x - gl_FragCoord.y) / 360.0 - GameTime * 400.0);
        float s = smoothstep(0.0, 0.06, b) * (1.0 - smoothstep(0.06, 0.12, b));
        color.rgb = mix(color.rgb, vec3(1.0, 0.93, 0.96), s * 0.6);
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
